document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            this.setAttribute('aria-expanded', !isExpanded);
            navLinks.classList.toggle('active');
            
            // Change icon
            const icon = this.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-times');
            }
        });
    }
    
    // Search tabs functionality
    const searchTabs = document.querySelectorAll('.search-tabs button');
    searchTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('aria-controls');
            
            // Update tab states
            searchTabs.forEach(t => {
                t.classList.remove('active');
                t.setAttribute('aria-selected', 'false');
            });
            
            this.classList.add('active');
            this.setAttribute('aria-selected', 'true');
            
            // In a real app, you would show/hide the corresponding tab content
            console.log(`Switched to ${tabId}`);
        });
    });
    
    // Booking functionality with loading state
    const bookButtons = document.querySelectorAll('.book-btn, .deal-btn');
    bookButtons.forEach(button => {
        button.addEventListener('click', function() {
            const card = this.closest('.activity-card, .deal-card');
            const activityName = card.querySelector('h4').textContent;
            const price = card.querySelector('.price, .discounted-price').textContent;
            
            // Show loading state
            this.classList.add('loading');
            
            // Simulate API call
            setTimeout(() => {
                this.classList.remove('loading');
                
                // Show confirmation
                showToast(`Successfully booked: ${activityName} for ${price}`);
                
                // In a real app, you would redirect or update the UI
            }, 1500);
        });
    });
    
    // Search functionality with validation
    const searchBtn = document.querySelector('.search-btn');
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            const destination = document.getElementById('destination').value.trim();
            const date = document.getElementById('travel-date').value;
            const travelers = document.getElementById('travelers').value;
            
            // Validate inputs
            if (!destination) {
                showToast('Please enter a destination', 'error');
                document.getElementById('destination').focus();
                return;
            }
            
            // Show loading state
            this.classList.add('loading');
            
            // Simulate search (in a real app, this would be an API call)
            setTimeout(() => {
                this.classList.remove('loading');
                
                // Show results (in a real app, you would display actual results)
                console.log(`Searching for ${travelers} travelers in ${destination} on ${date}`);
                showToast(`Found activities in ${destination}`);
                
                // Scroll to activities section
                document.getElementById('activities').scrollIntoView({
                    behavior: 'smooth'
                });
            }, 2000);
        });
    }
    
    // User dropdown toggle
    const userAvatar = document.querySelector('.user-avatar');
    if (userAvatar) {
        userAvatar.addEventListener('click', function(e) {
            e.stopPropagation();
            const dropdown = document.querySelector('.dropdown-menu');
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            
            this.setAttribute('aria-expanded', !isExpanded);
            dropdown.style.display = isExpanded ? 'none' : 'block';
        });
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function() {
        const dropdown = document.querySelector('.dropdown-menu');
        if (dropdown && dropdown.style.display === 'block') {
            dropdown.style.display = 'none';
            userAvatar.setAttribute('aria-expanded', 'false');
        }
    });
    
    // Activity filtering
    const filterButtons = document.querySelectorAll('.filter-btn');
    const activities = document.querySelectorAll('.activity-card');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Update active state
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Get filter category
            const filter = this.textContent.toLowerCase();
            
            // Filter activities
            activities.forEach(activity => {
                if (filter === 'all' || activity.dataset.category === filter) {
                    activity.style.display = 'block';
                } else {
                    activity.style.display = 'none';
                }
            });
            
            // Announce filter change for screen readers
            const liveRegion = document.getElementById('filter-live-region') || createLiveRegion();
            liveRegion.textContent = `Showing ${filter === 'all' ? 'all activities' : filter + ' activities'}`;
        });
    });
    
    // Create a live region for accessibility announcements
    function createLiveRegion() {
        const liveRegion = document.createElement('div');
        liveRegion.id = 'filter-live-region';
        liveRegion.setAttribute('aria-live', 'polite');
        liveRegion.setAttribute('aria-atomic', 'true');
        liveRegion.classList.add('visually-hidden');
        document.body.appendChild(liveRegion);
        return liveRegion;
    }
    
    // Set min date for date picker to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('travel-date')?.setAttribute('min', today);
    
    // Image error handling with multiple fallbacks
    document.querySelectorAll('img').forEach(img => {
        // Store original source
        if (!img.hasAttribute('data-original')) {
            img.setAttribute('data-original', img.src);
        }
        
        img.addEventListener('error', function() {
            this.classList.add('broken');
            
            // Try local fallback first
            const activityType = this.closest('.activity-card')?.dataset.category || 
                               this.closest('.destination-card') ? 'destination' : 
                               this.closest('.deal-card') ? 'deal' : 'general';
            
            const fallbackImages = {
                'family': 'https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg',
                'adventure': 'https://images.pexels.com/photos/2386318/pexels-photo-2386318.jpeg',
                'cultural': 'https://images.pexels.com/photos/1450360/pexels-photo-1450360.jpeg',
                'nature': 'https://images.pexels.com/photos/917510/pexels-photo-917510.jpeg',
                'destination': 'https://images.pexels.com/photos/164336/pexels-photo-164336.jpeg',
                'deal': 'https://images.pexels.com/photos/672532/pexels-photo-672532.jpeg',
                'general': 'https://images.pexels.com/photos/672532/pexels-photo-672532.jpeg'
            };
            
            // Try the appropriate fallback
            if (fallbackImages[activityType]) {
                this.src = fallbackImages[activityType];
            } else {
                // Ultimate fallback - SVG placeholder
                this.src = 'data:image/svg+xml;charset=UTF-8,%3Csvg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200"%3E%3Crect fill="%23e0e0e0" width="300" height="200"/%3E%3Ctext fill="%23666" font-family="sans-serif" font-size="14" dy=".35em" text-anchor="middle" x="150" y="100"%3EImage not available%3C/text%3E%3C/svg%3E';
            }
            
            console.warn('Image failed to load:', this.alt);
        });
    });
    
    // Simulate login state (for demo purposes)
    const simulateLogin = () => {
        document.querySelector('.login-btn').style.display = 'none';
        document.querySelector('.signup-btn').style.display = 'none';
        document.querySelector('.user-avatar').style.display = 'block';
        showToast('Login successful!');
    };
    
    // For demo purposes - remove in production
    document.querySelector('.login-btn')?.addEventListener('click', simulateLogin);
    document.querySelector('.signup-btn')?.addEventListener('click', simulateLogin);
    
    // Toast notification function
    function showToast(message, type = 'success') {
        // Remove existing toasts
        const existingToasts = document.querySelectorAll('.toast');
        existingToasts.forEach(toast => toast.remove());
        
        // Create new toast
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        
        document.body.appendChild(toast);
        
        // Show toast
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // Hide after delay
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
    
    // Add toast styles dynamically
    const toastStyles = document.createElement('style');
    toastStyles.textContent = `
        .toast {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #333;
            color: white;
            padding: 12px 24px;
            border-radius: 4px;
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: 1000;
        }
        .toast.show {
            opacity: 1;
        }
        .toast-success {
            background-color: #4CAF50;
        }
        .toast-error {
            background-color: #F44336;
        }
    `;
    document.head.appendChild(toastStyles);
});